package class07;

public class Inner<T> {
	public T value;

	public Inner(T v) {
		value = v;
	}
}
