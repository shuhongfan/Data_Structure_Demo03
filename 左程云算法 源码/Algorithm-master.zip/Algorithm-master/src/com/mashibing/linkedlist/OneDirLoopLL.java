package com.mashibing.linkedlist;

public class OneDirLoopLL {

}
